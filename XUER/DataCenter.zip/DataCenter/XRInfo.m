//
//  XRInfo.m
//  XUER
//
//  Created by 王方帅 on 15/8/31.
//  Copyright (c) 2015年 a. All rights reserved.
//

#import "XRInfo.h"

@implementation XRInfo

- (instancetype)initWithDic:(NSDictionary *)dic
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

+(NSArray *)arrayWithDicArray:(NSArray *)dicArray
{
    NSMutableArray *returnArray = [NSMutableArray array];
    for (NSDictionary *dic in dicArray)
    {
        [returnArray addObject:[[self alloc] initWithDic:dic]];
    }
    return returnArray;
}

@end
