//
//  XRSubTypeInfo.h
//  XUER
//
//  Created by 王方帅 on 15/8/31.
//  Copyright (c) 2015年 a. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "XRInfo.h"

@interface XRSubTypeInfo :XRInfo

@property (nonatomic,strong) NSString *arrchildid;//子分类id
@property (nonatomic,strong) NSString *name;

@end
