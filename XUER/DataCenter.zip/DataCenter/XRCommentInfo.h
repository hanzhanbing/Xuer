//
//  XRCommentInfo.h
//  XUER
//
//  Created by 王方帅 on 15/9/9.
//  Copyright (c) 2015年 a. All rights reserved.
//

#import "XRInfo.h"

@interface XRCommentInfo : XRInfo

@property (nonatomic,strong) NSString   *realname;
@property (nonatomic,strong) NSString   *logo;
@property (nonatomic,strong) NSString   *star;
@property (nonatomic,strong) NSString   *content;
@property (nonatomic,strong) NSString   *tm;

@end
