//
//  XRTypeInfo.m
//  XUER
//
//  Created by 王方帅 on 15/8/31.
//  Copyright (c) 2015年 a. All rights reserved.
//

#import "XRTypeInfo.h"

@implementation XRTypeInfo

- (instancetype)initWithDic:(NSDictionary *)dic
{
    self = [super initWithDic:dic];
    if (self) {
        _arrchildid = dic[kArrchildid];
        _name = dic[kName];
        _img = dic[kImg];
        _subTypeArray = [XRSubTypeInfo arrayWithDicArray:dic[kChildren]];
    }
    return self;
}

@end
