//
//  XRCommentInfo.m
//  XUER
//
//  Created by 王方帅 on 15/9/9.
//  Copyright (c) 2015年 a. All rights reserved.
//

#import "XRCommentInfo.h"

@implementation XRCommentInfo

- (instancetype)initWithDic:(NSDictionary *)dic
{
    self = [super initWithDic:dic];
    if (self) {
        _realname = dic[kRealname];
        _logo = dic[kLogo];
        _star = dic[kStar];
        _content = dic[kContent];
        _tm = dic[kTm];
    }
    return self;
}

@end
