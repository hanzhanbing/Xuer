//
//  XRTeacherInfo.h
//  XUER
//
//  Created by 王方帅 on 15/9/8.
//  Copyright (c) 2015年 a. All rights reserved.
//

#import "XRInfo.h"

@interface XRTeacherInfo : XRInfo

@property (nonatomic,strong) NSString   *realname;
@property (nonatomic,strong) NSString   *tp;
@property (nonatomic,strong) NSString   *sex;
@property (nonatomic,strong) NSString   *logo;
@property (nonatomic,strong) NSString   *teach_introduce;

@end
