//
//  XRCourseListInfo.h
//  XUER
//
//  Created by 王方帅 on 15/9/4.
//  Copyright (c) 2015年 a. All rights reserved.
//

#import "XRInfo.h"

@interface XRCourseListInfo : XRInfo

@property (nonatomic,strong) NSString *courseId;
@property (nonatomic,strong) NSString *thumb;
@property (nonatomic,strong) NSString *stitle;
@property (nonatomic,strong) NSString *progress;

@end
