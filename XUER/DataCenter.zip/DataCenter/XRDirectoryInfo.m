//
//  XRDirectoryInfo.m
//  XUER
//
//  Created by 王方帅 on 15/9/9.
//  Copyright (c) 2015年 a. All rights reserved.
//

#import "XRDirectoryInfo.h"

@implementation XRDirectoryInfo

- (instancetype)initWithDic:(NSDictionary *)dic
{
    self = [super initWithDic:dic];
    if (self) {
        _sectionID = dic[kId];
        _title = dic[kTitle];
        _updatetime = dic[kUpdatetime];
        _mv_url = dic[kMv_url];
        _kc_hours = dic[kKc_hours];
        _isstudied = dic[kIsstudied];
    }
    return self;
}

@end
