//
//  XRTeacherInfo.m
//  XUER
//
//  Created by 王方帅 on 15/9/8.
//  Copyright (c) 2015年 a. All rights reserved.
//

#import "XRTeacherInfo.h"

@implementation XRTeacherInfo

- (instancetype)initWithDic:(NSDictionary *)dic
{
    self = [super initWithDic:dic];
    if (self) {
        _realname = dic[kRealname];
        _tp = dic[kTp];
        _sex = dic[kSex];
        _logo = dic[kLogo];
        _teach_introduce = dic[kTeach_introduce];
    }
    return self;
}

@end
