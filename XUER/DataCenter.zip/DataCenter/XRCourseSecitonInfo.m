//
//  XRCourseSecitonInfo.m
//  XUER
//
//  Created by 王方帅 on 15/9/10.
//  Copyright (c) 2015年 a. All rights reserved.
//

#import "XRCourseSecitonInfo.h"

@implementation XRCourseSecitonInfo

- (instancetype)initWithDic:(NSDictionary *)dic
{
    self = [super initWithDic:dic];
    if (self) {
        _title = dic[kTitle];
        _courseArray = [XRCourseItemInfo arrayWithDicArray:dic[kCourse]];
    }
    return self;
}

@end
