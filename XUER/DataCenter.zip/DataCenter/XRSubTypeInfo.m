//
//  XRSubTypeInfo.m
//  XUER
//
//  Created by 王方帅 on 15/8/31.
//  Copyright (c) 2015年 a. All rights reserved.
//

#import "XRSubTypeInfo.h"

@implementation XRSubTypeInfo

- (instancetype)initWithDic:(NSDictionary *)dic
{
    self = [super init];
    if (self) {
        _arrchildid = dic[kArrchildid];
        _name = dic[kName];
    }
    return self;
}

@end
