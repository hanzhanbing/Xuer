//
//  XRCourseListInfo.m
//  XUER
//
//  Created by 王方帅 on 15/9/4.
//  Copyright (c) 2015年 a. All rights reserved.
//

#import "XRCourseListInfo.h"

@implementation XRCourseListInfo

- (instancetype)initWithDic:(NSDictionary *)dic
{
    self = [super initWithDic:dic];
    if (self) {
        _courseId = dic[kCatid];
        _stitle = dic[kStitle];
        _thumb = dic[kThumb];
    }
    return self;
}

@end
