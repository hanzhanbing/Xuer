//
//  XRDirectoryInfo.h
//  XUER
//
//  Created by 王方帅 on 15/9/9.
//  Copyright (c) 2015年 a. All rights reserved.
//

#import "XRInfo.h"

@interface XRDirectoryInfo : XRInfo

@property (nonatomic,strong) NSString   *sectionID;
@property (nonatomic,strong) NSString   *title;
@property (nonatomic,strong) NSString   *updatetime;
@property (nonatomic,strong) NSString   *mv_url;
@property (nonatomic,strong) NSString   *kc_hours;
@property (nonatomic,strong) NSString   *isstudied;

@end
