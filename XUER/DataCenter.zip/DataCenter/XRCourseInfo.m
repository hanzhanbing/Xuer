//
//  XRCourseInfo.m
//  XUER
//
//  Created by 王方帅 on 15/9/8.
//  Copyright (c) 2015年 a. All rights reserved.
//

#import "XRCourseInfo.h"

@implementation XRCourseInfo

- (instancetype)initWithDic:(NSDictionary *)dic
{
    self = [super init];
    if (self) {
        _teacherArray = (NSMutableArray *)[XRTeacherInfo arrayWithDicArray:dic[kTeacherlist]];
        _directoryArray = (NSMutableArray *)[XRDirectoryInfo arrayWithDicArray:dic[kChildren]];
        _commentArray = (NSMutableArray *)[XRCommentInfo arrayWithDicArray:dic[kComment]];
        
        _stitle = dic[kStitle];
        _catid = dic[kCatid];
        _introduce = dic[kIntroduce];
        _isjoin = dic[kIsjoin];
        _sys_hours = dic[kSys_hours];
        _listorder = dic[kListorder];
        _thumb = dic[kThumb];
        
    }
    return self;
}

@end
