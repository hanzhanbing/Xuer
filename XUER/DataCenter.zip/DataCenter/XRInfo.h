//
//  XRInfo.h
//  XUER
//
//  Created by 王方帅 on 15/8/31.
//  Copyright (c) 2015年 a. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XRInfo : NSObject

- (instancetype)initWithDic:(NSDictionary *)dic;

+(NSArray *)arrayWithDicArray:(NSArray *)dicArray;

@end
